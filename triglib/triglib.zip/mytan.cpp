//CS375 Homework 1
//Austin Willis

#include "mytrig.h"
using namespace std;
double mytan(double angle)
{
  return (mysin(angle)/mycos(angle));
}
