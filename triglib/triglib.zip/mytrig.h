//CS375 Homework 1
//Austin Willis

double mysin(double angle);
double mycos(double angle);
double mytan(double angle);
